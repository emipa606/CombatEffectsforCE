﻿using System;
using UnityEngine;
using Verse;



namespace CombatEffectsCE
{
    // Token: 0x02000B52 RID: 2898
    public class MotePropertiesFilthy : MoteProperties
    {
        public ThingDef filthTrace;
    }
}
